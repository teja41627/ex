# SpendAI.online — MVP starter

Generated project ZIP for SpendAI.online MVP.
Contains backend (FastAPI) and frontend (Next.js) starter code.
