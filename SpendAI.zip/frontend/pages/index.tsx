import React, { useState } from 'react'
import axios from 'axios'

export default function Home(){
  const [file, setFile] = useState<File | null>(null)
  const [email, setEmail] = useState('user@example.com')
  const [msg, setMsg] = useState('')

  async function upload(){
    if(!file) return alert('pick a file')
    const fd = new FormData()
    fd.append('file', file)
    fd.append('email', email)
    setMsg('Uploading...')
    try{
      const res = await axios.post('http://localhost:8000/upload-csv/', fd, { headers: {'Content-Type':'multipart/form-data'}})
      setMsg(JSON.stringify(res.data))
    }catch(e:any){
      setMsg('Error: '+(e.message||e.toString()))
    }
  }

  async function askAdvisor(){
    setMsg('Asking...')
    const q = prompt('Ask SpendAI a question (e.g. Where can I cut ₹2000)?')
    if(!q) return
    try{
      const res = await axios.post('http://localhost:8000/advisor/', null, { params: { email, question: q }})
      setMsg(res.data.answer)
    }catch(e:any){
      setMsg('Error: '+(e.message||e.toString()))
    }
  }

  return (
    <div style={{padding:24,fontFamily:'Inter, Arial'}}>
      <h1>SpendAI — MVP</h1>
      <p>Upload a CSV bank export and ask the AI advisor.</p>
      <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="email" />
      <br/><br/>
      <input type="file" onChange={e=> setFile(e.target.files ? e.target.files[0] : null)} />
      <button onClick={upload}>Upload CSV</button>
      <hr/>
      <button onClick={askAdvisor}>Ask AI Advisor</button>
      <pre style={{whiteSpace:'pre-wrap',marginTop:12}}>{msg}</pre>
    </div>
  )
}
