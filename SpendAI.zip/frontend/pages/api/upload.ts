// Optional: proxy example (not fully implemented)
import type { NextApiRequest, NextApiResponse } from 'next'
import formidable from 'formidable'
import fs from 'fs'

export const config = { api: { bodyParser: false } }

export default async function handler(req: NextApiRequest, res: NextApiResponse){
  const form = new formidable.IncomingForm()
  form.parse(req, async (err, fields, files) => {
    if(err) return res.status(500).json({error:err.message})
    const f:any = files.file
    const buf = fs.readFileSync(f.filepath)
    res.json({ok:true})
  })
}
