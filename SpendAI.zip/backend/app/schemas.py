from pydantic import BaseModel
from typing import Optional, List, Any
from datetime import datetime

class ExpenseCreate(BaseModel):
    date: datetime
    amount: float
    merchant: Optional[str]
    raw_description: Optional[str]

class ExpenseOut(ExpenseCreate):
    id: int
    category: Optional[str]
    tags: List[str]
    is_recurring: bool
    meta: Any

    class Config:
        orm_mode = True

class UserCreate(BaseModel):
    email: str
    name: Optional[str]

class UserOut(BaseModel):
    id: int
    email: str
    name: Optional[str]

    class Config:
        orm_mode = True
