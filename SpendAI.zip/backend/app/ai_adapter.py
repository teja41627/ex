from typing import Tuple, List

CATEGORY_KEYWORDS = {
    'food': ['restaurant','cafe','dominos','zomato','swiggy','restaurant','kfc','mcdonalds','cafe'],
    'saaS': ['mojo','notion','figma','aws','google cloud','github','gitlab','stripe','netflix','spotify'],
    'travel': ['uber','ola','airline','indigo','goair','train','irctc','flight','booking'],
    'rent': ['rent','landlord','apartment','lease'],
    'grocery': ['grocery','bigbasket','dmart','patanjali']
}

def classify_expense_text(text: str) -> Tuple[str, List[str]]:
    t = (text or '').lower()
    tags = []
    for cat, kws in CATEGORY_KEYWORDS.items():
        for k in kws:
            if k in t:
                tags.append(cat)
                return cat, [k]
    return 'other', []

def detect_recurring(expenses_texts: List[str]) -> bool:
    from collections import Counter
    c = Counter([ (t or '').lower() for t in expenses_texts ])
    for k,v in c.items():
        if v>=3:
            return True
    return False

async def llm_advice(prompt: str) -> str:
    return ("If you cancel two subscriptions costing ₹1200 and ₹800 per month, you'll save ₹2000/month (₹24,000/yr)."
            "Consider moving frequent food orders to a weekly meal prep to save ~₹1500/month.")
