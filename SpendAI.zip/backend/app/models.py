from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, ForeignKey, JSON
from sqlalchemy.orm import relationship
from .db import Base
import datetime

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    name = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    expenses = relationship('Expense', back_populates='user')

class Expense(Base):
    __tablename__ = 'expenses'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    date = Column(DateTime)
    amount = Column(Float)
    merchant = Column(String)
    raw_description = Column(String)
    category = Column(String, index=True)
    tags = Column(JSON, default=[])
    is_recurring = Column(Boolean, default=False)
    meta = Column(JSON, default={})

    user = relationship('User', back_populates='expenses')

class Alert(Base):
    __tablename__ = 'alerts'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    name = Column(String)
    condition = Column(String)
    active = Column(Boolean, default=True)

    user = relationship('User')
