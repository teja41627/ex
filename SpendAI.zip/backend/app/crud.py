from sqlalchemy.orm import Session
from . import models, schemas
import datetime

def get_or_create_user(db: Session, email: str, name: str = None):
    u = db.query(models.User).filter(models.User.email == email).first()
    if u:
        return u
    u = models.User(email=email, name=name)
    db.add(u)
    db.commit()
    db.refresh(u)
    return u

def create_expense(db: Session, user: models.User, expense_in: schemas.ExpenseCreate, category=None, tags=None, is_recurring=False, meta=None):
    e = models.Expense(
        user_id=user.id,
        date=expense_in.date,
        amount=expense_in.amount,
        merchant=expense_in.merchant,
        raw_description=expense_in.raw_description,
        category=category,
        tags=tags or [],
        is_recurring=is_recurring,
        meta=meta or {}
    )
    db.add(e)
    db.commit()
    db.refresh(e)
    return e

def list_expenses(db: Session, user: models.User, limit: int = 100):
    return db.query(models.Expense).filter(models.Expense.user_id == user.id).order_by(models.Expense.date.desc()).limit(limit).all()
