from fastapi import FastAPI, Depends, File, UploadFile, HTTPException
from . import db, models, crud, schemas, utils, ai_adapter
from .db import engine
import os

models.Base.metadata.create_all(bind=engine)

app = FastAPI(title='SpendAI MVP')

@app.post('/upload-csv/')
async def upload_csv(email: str, file: UploadFile = File(...), database: next = Depends(db.get_db)):
    content = await file.read()
    rows = utils.parse_csv_bytes(content)
    user = crud.get_or_create_user(database, email=email)
    created = []
    texts = []
    for r in rows:
        cat, tags = ai_adapter.classify_expense_text(r.get('raw_description') or '')
        e_in = schemas.ExpenseCreate(date=r['date'], amount=r['amount'], merchant=r['merchant'], raw_description=r['raw_description'])
        e = crud.create_expense(database, user, e_in, category=cat, tags=tags)
        created.append(e)
        texts.append(r.get('merchant') or r.get('raw_description'))
    recurring_flag = ai_adapter.detect_recurring(texts)
    return {'created': len(created), 'recurring_detected': recurring_flag}

@app.get('/expenses/')
def list_expenses(email: str, database: next = Depends(db.get_db)):
    user = database.query(models.User).filter(models.User.email==email).first()
    if not user:
        raise HTTPException(404, 'user not found')
    exps = crud.list_expenses(database, user)
    return exps

@app.post('/advisor/')
async def advisor_query(email: str, question: str, database: next = Depends(db.get_db)):
    user = database.query(models.User).filter(models.User.email==email).first()
    if not user:
        raise HTTPException(404, 'user not found')
    exps = crud.list_expenses(database, user, limit=200)
    sample_text = '\n'.join([f"{e.date.date()} | {e.merchant} | {e.amount} | {e.category}" for e in exps[:30]])
    prompt = f"User expenses:\n{sample_text}\n\nQuestion: {question}\n\nGive short actionable suggestions with numbers in INR."
    resp = await ai_adapter.llm_advice(prompt)
    return {'answer': resp}

if __name__ == '__main__':
    import uvicorn
    uvicorn.run('app.main:app', host='0.0.0.0', port=int(os.getenv('PORT', 8000)), reload=True)
