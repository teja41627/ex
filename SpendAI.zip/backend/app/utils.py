import pandas as pd
from datetime import datetime
from io import BytesIO
import csv

def parse_csv_bytes(content: bytes):
    try:
        df = pd.read_csv(BytesIO(content))
    except Exception:
        text = content.decode('utf-8', errors='ignore')
        reader = csv.DictReader(text.splitlines())
        df = pd.DataFrame(list(reader))

    colmap = {c.lower(): c for c in df.columns}

    date_col = None
    for candidate in ['date','transaction date','value date','txn date','timestamp']:
        if candidate in colmap:
            date_col = colmap[candidate]
            break

    amt_col = None
    for candidate in ['amount','amt','debit','credit','value']:
        if candidate in colmap:
            amt_col = colmap[candidate]
            break

    desc_col = None
    for candidate in ['remarks','description','narration','particulars','details']:
        if candidate in colmap:
            desc_col = colmap[candidate]
            break

    rows = []
    for _, r in df.iterrows():
        raw = r.to_dict()
        try:
            date = None
            if date_col:
                date = pd.to_datetime(r[date_col], errors='coerce')
            else:
                date = pd.NaT
            amount = None
            if amt_col:
                v = r[amt_col]
                try:
                    amount = float(str(v).replace(',',''))
                except:
                    amount = 0.0
            merchant = None
            desc = None
            if desc_col:
                desc = str(r[desc_col])
                merchant = desc.split()[:3]
                merchant = ' '.join(merchant)
            rows.append({
                'date': date.to_pydatetime() if pd.notna(date) else datetime.utcnow(),
                'amount': float(amount or 0.0),
                'merchant': merchant,
                'raw_description': desc,
                'raw_row': raw
            })
        except Exception:
            continue
    return rows
